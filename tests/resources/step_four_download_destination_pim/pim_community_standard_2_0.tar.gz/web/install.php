You need to install Akeneo PIM.<br />
Please, launch pim:install command !
If already done, launch cache:clear command
